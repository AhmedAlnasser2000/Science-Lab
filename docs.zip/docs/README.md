﻿# Docs Index

This folder holds checkpoint summaries, plans, prompts, and overview notes for PhysicsLab.

## Canonical checkpoint
- `docs/app_summary_latest.md`: current, code-verified checkpoint summary.

## Checkpoints and inputs
- `docs/checkpoints/README.md`: checkpoint conventions and workflow.
- `docs/checkpoints/history/`: archived checkpoint snapshots (date/hash in filename).
- `docs/checkpoints/inputs/`: raw input artifacts used during reconciliation.

## Reference docs
- `docs/handbook/app_handbook.md`: contributor handbook.
- `docs/handbook/agent_safety_rules.md`: Codex/agent safety header.
- `docs/handbook/workflow_rules.md`: workflow rules (MVP vs UX).
- `docs/handbook/dev_setup.md`: development setup.
- `docs/handbook/standard_terms.md`: standard UI terms.
- `docs/overviews/`: version overviews.
- `docs/plans/`: design plans.
- `docs/prompts/`: diagram and tooling prompts.
- `docs/snapshots/`: captured repo trees or other snapshots.
- `docs/milestones/README.md`: milestone artifacts (migrated from repo-root Milestones).
- `docs/human_dictionary/INDEX.md`: plain-English dictionary for non-engineering readers.

## Adding a new checkpoint
1) Update `docs/app_summary_latest.md`.
2) Copy the previous `docs/app_summary_latest.md` into `docs/checkpoints/history/` using date + git hash.
3) Record verification commands and manual checks in the summary appendix.

## Pillars harness (scaffold)
- Run tests: `pytest -q tests/pillars`
- Run CLI: `python tools/pillars_harness.py --out <folder>` (writes `pillars_report.json`)
